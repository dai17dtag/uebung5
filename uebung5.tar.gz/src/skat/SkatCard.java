package skat;

import cardgame.PlayingCard;

public class SkatCard extends PlayingCard
{
    private final String[] ranks =
            {
                    "7",
                    "8",
                    "9",
                    "10",
                    "Bube",
                    "Dame",
                    "Koenig",
                    "Ass"
            };

    private final String[] suits =
            {
                    "Karo",
                    "Herz",
                    "Pik",
                    "Kreuz"
            };

    public SkatCard(String suit, String rank)
    {
        super(suit, rank);
    }


}
