package skat;

public class SkatGame
{
}
