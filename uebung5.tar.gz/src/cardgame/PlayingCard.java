package cardgame;

import Exceptions.InvalidRankException;
import Exceptions.InvalidSuitException;

public abstract class PlayingCard
{
    public final String suit;
    public final String rank;

    private final String[] suits = {};
    private final String[] ranks = {};

    public PlayingCard (String suit, String rank)
    {
        this.suit = suit;
        this.rank = rank;
    }

    public int compareTo (PlayingCard compareCard)
    {
        Enumerate enumerate = new Enumerate(ranks, suits);

        int comparisonResult;

        try
        {
            int rankEnumerated = enumerate.rank(rank);
            int rankEnumeratedCompare = enumerate.rank(compareCard.rank);
            int suitEnumerated = enumerate.suit(suit);
            int suitEnumeratedCompare = enumerate.suit(compareCard.suit);

            if (
                    rankEnumerated == rankEnumeratedCompare
                    && suitEnumerated == suitEnumeratedCompare
               )
            {
                comparisonResult = 0;
            }
            else if (
                    rankEnumerated > rankEnumeratedCompare
                    || suitEnumerated > suitEnumeratedCompare
                    )
            {
                comparisonResult = 1;
            }
            else
            {
                comparisonResult = 0;
            }

        }catch (InvalidSuitException | InvalidRankException e)
        {
            System.out.println(e.toString());
            comparisonResult = -1;
        }

        return comparisonResult;
    }

    public String toString()
    {
        return suit + " " + rank;
    }
}
